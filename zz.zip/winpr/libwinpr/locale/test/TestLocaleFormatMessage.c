
#include <winpr/crt.h>

int TestLocaleFormatMessage(int argc, char* argv[])
{
	return 0;
}
