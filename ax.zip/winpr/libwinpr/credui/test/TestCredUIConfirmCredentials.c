
#include <stdio.h>
#include <winpr/crt.h>
#include <winpr/tchar.h>
#include <winpr/credui.h>
#include <winpr/windows.h>

int TestCredUIConfirmCredentials(int argc, char* argv[])
{
	return 0;
}
